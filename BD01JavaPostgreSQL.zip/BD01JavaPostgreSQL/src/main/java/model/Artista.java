package model;

public class Artista {
	private int codigo;
	private String genero;
	private String nome;
	private String nacionalidade;
	
	public Artista() {
		this.codigo = 0;
		this.genero = "";
		this.nome = "";
		this.nacionalidade = "";
	}
	
	public Artista(int codigo, String genero, String nome, String nacionalidade) {
		this.codigo = 0;
		this.genero = "";
		this.nome = "";
		this.nacionalidade = "";
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}
	

	@Override
	public String toString() {
		return "Artista [codigo=" + codigo + ", genero=" + genero + ", nome=" + nome + ", nacionalidade=" + nacionalidade + "]";
	}	
}
