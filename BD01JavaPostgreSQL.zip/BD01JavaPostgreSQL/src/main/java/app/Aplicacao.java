package app;

import java.util.List;

import dao.DAO;
import dao.ArtistaDAO;
import model.Artista;

public class Aplicacao {
	
	public static void main(String[] args) throws Exception {
		
		ArtistaDAO artistaDAO = new ArtistaDAO();
		
		System.out.println("\n\n==== Inserir artista === ");
		Artista artista = new Artista(0, "sertanejo", "Marilia", "brasileira");
		if(artistaDAO.insert(artista) == true) {
			System.out.println("Inserção com sucesso -> " + artista.toString());
		}
		
		/*System.out.println("\n\n==== Testando autenticação ===");
		System.out.println("Usuário (" + usuario.getLogin() + "): " + usuarioDAO.autenticar("pablo", "pablo"));*/
			
		System.out.println("\n\n==== Mostrar artistas do genero sertanejo === ");
		List<Artista> artistas = artistaDAO.getGeneroSertanejo();
		for (Artista u: artistas) {
			System.out.println(u.toString());
		}

		/*System.out.println("\n\n==== Atualizar senha (código (" + usuario.getCodigo() + ") === ");
		usuario.setSenha(DAO.toMD5("pablo"));
		usuarioDAO.update(usuario);*/
		
		/*System.out.println("\n\n==== Testando autenticação ===");
		System.out.println("Usuário (" + usuario.getLogin() + "): " + usuarioDAO.autenticar("pablo", DAO.toMD5("pablo")));		
		
		System.out.println("\n\n==== Invadir usando SQL Injection ===");
		System.out.println("Usuário (" + usuario.getLogin() + "): " + usuarioDAO.autenticar("pablo", "x' OR 'x' LIKE 'x"));*/

		System.out.println("\n\n==== Mostrar artistas ordenados por código === ");
		artistas = artistaDAO.getOrderByCodigo();
		for (Artista u: artistas) {
			System.out.println(u.toString());
		}
		
		System.out.println("\n\n==== Excluir artista (código " + artista.getCodigo() + ") === ");
		artistaDAO.delete(artista.getCodigo());
		
		/*System.out.println("\n\n==== Mostrar usuários ordenados por login === ");
		usuarios = usuarioDAO.getOrderByLogin();
		for (Usuario u: usuarios) {
			System.out.println(u.toString());
		}*/
	}
}