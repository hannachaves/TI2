package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Artista;

public class ArtistaDAO extends DAO {
	
	public ArtistaDAO() {
		super();
		conectar();
	}

	public void finalize() {
		close();
	}
	
	
	public boolean insert(Artista artista) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			String sql = "INSERT INTO artista (codigo, genero, nome, nacionalidade) "
				       + "VALUES ("+artista.getCodigo()+ ", '" + artista.getGenero() + "', '"  
				       + artista.getNome() + "', '" + artista.getNacionalidade() + "');";
			System.out.println(sql);
			st.executeUpdate(sql);
			st.close();
			status = true;
		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}

	
	public Artista get(int codigo) {
		Artista artista = null;
		
		try {
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT * FROM produto WHERE id=" + codigo;
			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);	
	        if(rs.next()){            
	        	 artista = new Artista(rs.getInt("codigo"), rs.getString("genero"), rs.getString("nome"), rs.getString("nacionalidade"));
	        }
	        st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return artista;
	}
	
	
	public List<Artista> get() {
		return get("");
	}

	
	public List<Artista> getOrderByCodigo() {
		return get("codigo");		
	}
	
	
	public List<Artista> getOrderByGenero() {
		return get("genero");		
	}
	
	
	public List<Artista> getOrderByNome() {
		return get("nome");		
	}
	
	public List<Artista> getOrderByNacionalidade() {
		return get("nacionalidade");		
	}
	
	private List<Artista> get(String orderBy) {	
	
		List<Artista> artistas = new ArrayList<Artista>();
		
		try {
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT * FROM artista" + ((orderBy.trim().length() == 0) ? "" : (" ORDER BY " + orderBy));
			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);	           
	        while(rs.next()) {	            	
	        	Artista u = new Artista(rs.getInt("codigo"), rs.getString("genero"), rs.getString("nome"), rs.getString("nacionalidade"));
	            artistas.add(u);
	        }
	        st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return artistas;
	}


	public List<Artista> getGeneroSertanejo() {
		List<Artista> artistas = new ArrayList<Artista>();
		
		try {
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT * FROM artista WHERE artista.genero LIKE 'sertanejo'";
			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);	           
	        while(rs.next()) {	            	
	        	Artista u = new Artista(rs.getInt("codigo"), rs.getString("genero"), rs.getString("nome"), rs.getString("nacionalidade"));
	            artistas.add(u);
	        }
	        st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return artistas;
	}
	
	
	public boolean update(Artista artista) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			String sql = "UPDATE artista SET genero = '" + artista.getGenero() + "', nome = '"  
				       + artista.getNome() + "', nacionalidade = '" + artista.getNacionalidade() + "'"
					   + " WHERE codigo = " + artista.getCodigo();
			System.out.println(sql);
			st.executeUpdate(sql);
			st.close();
			status = true;
		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	public boolean delete(int codigo) {
		boolean status = false;
		try {  
			Statement st = conexao.createStatement();
			String sql = "DELETE FROM artista WHERE codigo = " + codigo;
			System.out.println(sql);
			st.executeUpdate(sql);
			st.close();
			status = true;
		} catch (SQLException u) {  
			throw new RuntimeException(u);
		}
		return status;
	}
	
	
	/*public boolean autenticar(String login, String senha) {
		boolean resp = false;
		
		try {
			Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			String sql = "SELECT * FROM usuario WHERE login LIKE '" + login + "' AND senha LIKE '" + senha  + "'";
			System.out.println(sql);
			ResultSet rs = st.executeQuery(sql);
			resp = rs.next();
	        st.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return resp;
	}	*/
}